#!/bin/sh
# 热点联动移动数据 -- the background half of the hotspotdata info screen app.
#
#   hotspot turned off -> mobile data down (after off_delay minutes), and with
#                         mode "radio" the data card's radio off as well
#   hotspot turned on  -> the radio back on, mobile data up
#   and with perf_low, the CPU and GPU at their lowest clocks while it is off
#
# The hotspot's state is its configuration: the first wifi-iface in mode ap and
# its radio, not disabled -- what the screen, LuCI and the dashboard all change
# (/usr/libexec/unisoc-modem/hotspot.uc).  Data is the netifd interface the
# dashboard's own data switch uses (unisoc_modem.main.data_interface, wan).
#
# Modes (e5-plugin-hotspotdata.settings.mode):
#   radio  the cellular radio off.  ModemManager's disable (the proto's
#          teardown, network.<wan>.disable_modem default 1) is not enough on
#          this modem: the card stays at CFUN 1, camped (t551m-sim-status still
#          reads its operator).  So the data card also gets AT+CFUN=4 -- radio
#          off, SIM kept, what the dashboard does to a standby card -- through
#          the AT adapter with the card selected (MU300_SIM_SLOT ->
#          AT+SPACTCARD), and AT+CFUN=1 before data comes back.  Never
#          AT+CFUN=0 or SFUN=3/5: after those the SIM is gone until a reboot
#          (api.uc, at_warning).  No SMS and no calls while it is off.
#   data   data only: disable_modem 0 keeps the modem registered, so SMS and
#          calls still come in.
#
# While the hotspot is off, network.<wan>.auto is 0 as well, so that a boot, a
# network reload or the modem coming back does not dial again behind our back;
# anything that still brings the interface up (a SIM switch, an APN change, the
# reconnect button, the dashboard's radio button) is taken down again at the
# next check, and in mode radio the radio is checked (AT+CFUN?) every
# RADIO_RETRY s and turned off again.  While the hotspot is on, data is only
# raised on the change: turning data off by hand then stays.
#
# /etc/init.d/hotspot-data runs this under procd; the app's backend installs
# that.  When the app is removed or the linking turned off, this gives back
# what it changed (auto, disable_modem, the radio); a removed app also removes
# the service.

DIR=/etc/e5-infoscreen/plugins/hotspotdata
CFG=e5-plugin-hotspotdata
INIT=/etc/init.d/hotspot-data
AT=/usr/libexec/unisoc-modem/at
# MARK.<card>: a card whose radio we turned off (kept until a reboot, which
# powers it anyway); one each, so a data SIM switched while off is given back too
MARK=/var/run/hotspotdata.radio-off
# t551m-sim-status reads both cards over AT every 5 s, radio off or not; with
# pause_sim_status it is stopped while the radio is off (PAUSED: stopped by us,
# so started again by us).  Its readers (the status bar, the dashboard's
# per-card rows) take a reading older than 15 s as unknown.  Our own AT goes
# through e5-at, not through it.
SIMSTAT=/etc/init.d/t551m-sim-status
PAUSED=/var/run/hotspotdata.simstatus-paused
INTERVAL=3
RADIO_RETRY=30
MODEM_LOST=60
RECOVER_GAP=600

log() { logger -t hotspotdata -- "$*"; }

data_iface() {
	local i
	i=$(uci -q get unisoc_modem.main.data_interface)
	echo "${i:-wan}"
}

# the data SIM (sipc_wwan card=, e5-sim)
data_card() {
	local c
	c=$(cat /sys/module/sipc_wwan/parameters/card 2>/dev/null)
	case "$c" in 0|1) echo "$c" ;; *) echo 0 ;; esac
}

hotspot_on() {
	local ap radio
	ap=$(uci -q show wireless | sed -n "s/^wireless\.\([^.]*\)\.mode='ap'$/\1/p" | head -n 1)
	[ -n "$ap" ] || return 1
	radio=$(uci -q get "wireless.$ap.device")
	[ "$(uci -q get "wireless.$ap.disabled")" != 1 ] &&
		[ "$(uci -q get "wireless.$radio.disabled")" != 1 ]
}

enabled() { [ "$(uci -q get "$CFG.settings.enabled")" != 0 ]; }

mode() {
	case "$(uci -q get "$CFG.settings.mode")" in
		data) echo data ;;
		*) echo radio ;;
	esac
}

off_delay() {
	local d
	d=$(uci -q get "$CFG.settings.off_delay")
	case "$d" in ''|*[!0-9]*) d=0 ;; esac
	echo $((d * 60))
}

uptime_s() { cut -d. -f1 /proc/uptime; }

# 0: up or dialling; 1: down
data_active() {
	local st
	st=$(ifstatus "$1" 2>/dev/null) || return 1
	[ "$(echo "$st" | jsonfilter -e '@.up')" = true ] ||
		[ "$(echo "$st" | jsonfilter -e '@.pending')" = true ]
}

# would netifd dial it on its own (at boot, when the modem appears)?
data_autostart() {
	[ "$(ifstatus "$1" 2>/dev/null | jsonfilter -e '@.autostart')" = true ]
}

# ModemManager's state of the modem: disabled, enabled, registered, ... or
# nothing while there is none
modem_state() {
	mmcli -m any -K 2>/dev/null | sed -n 's/^modem\.generic\.state *: *//p' | head -n 1
}

# the card's radio: 1 on, 4 off, 0 minimum; nothing when the AT owner does not answer
cfun_get() {
	MU300_SIM_SLOT=$1 "$AT" -t 10 'AT+CFUN?' 2>/dev/null |
		sed -n 's/.*+CFUN: *\([0-9]*\).*/\1/p' | head -n 1
}

cfun_set() {
	MU300_SIM_SLOT=$1 "$AT" -t 15 "AT+CFUN=$2" 2>/dev/null | grep -q '^OK'
}

pause_wanted() { [ "$(uci -q get "$CFG.settings.pause_sim_status")" != 0 ]; }

# (also when something started it again while paused)
sim_status_pause() {
	[ -x "$SIMSTAT" ] || return
	ubus call service list '{"name":"t551m-sim-status"}' 2>/dev/null |
		grep -q '"running": *true' || return
	: > "$PAUSED"
	"$SIMSTAT" stop >/dev/null 2>&1
	log "radio off: SIM status polling (t551m-sim-status) paused"
}

# While the poller is paused and the radio off, its file says so in its place:
# the data card "disabled" (CFUN not 1, as the poller itself writes it) with
# 射频关闭 for an operator, which the status bar shows instead of 搜索中 (it
# says 搜索中 for a modem without an operator).  Fresh every loop -- readers
# take a row older than 15 s (/proc/uptime) as unknown; the other card's row
# is written old, so it reads as unknown.  The poller overwrites it on resume.
SIMS=/run/t551m-sims.json
sims_write_off() {
	local c up r0 r1 row off stale
	c=$(data_card)
	up=$(cut -d' ' -f1 /proc/uptime)
	off="{\"slot\":$c,\"updated\":$up,\"present\":true,\"registration\":\"disabled\",\"operator\":\"射频关闭\",\"tech\":null,\"radio_label\":null,\"signal\":{},\"error\":null}"
	stale="{\"slot\":$((1 - c)),\"updated\":0,\"present\":null,\"registration\":\"unknown\",\"operator\":null,\"tech\":null,\"radio_label\":null,\"signal\":{},\"error\":\"paused\"}"
	if [ "$c" = 0 ]; then r0=$off r1=$stale; else r0=$stale r1=$off; fi
	printf '{"updated":%s,"active":%s,"sims":[%s,%s]}\n' "$up" "$c" "$r0" "$r1" > "$SIMS.hotspotdata" &&
		mv -f "$SIMS.hotspotdata" "$SIMS"
}

# With the hotspot off (perf_low): every CPU policy and the GPU (a devfreq
# device named *gpu*/*mali*) held at their lowest frequency, min and max both.
# What was there is kept in PERF ("path value", in the order to write it back:
# max before min) and written back when the hotspot is on again or the linking
# off.  The same sysfs limits cpu-control (LuCI's and the screen's CPU page)
# sets at runtime; its saved profile (/etc/e5-cpu.json) is not touched, and a
# reboot starts from that profile anyway.  DDR is left alone: its controller
# is shared with the modem and the display.
CPUFREQ=/sys/devices/system/cpu/cpufreq
DEVFREQ=/sys/class/devfreq
PERF=/var/run/hotspotdata.perf
perf_wanted() { [ "$(uci -q get "$CFG.settings.perf_low")" != 0 ]; }

lowest() {
	tr ' ' '\n' < "$1" 2>/dev/null | grep -E '^[0-9]+$' | sort -n | head -n 1
}

# one limit's current value: the requested one where this kernel has it
# (the effective one may be under a thermal cap)
limit_now() {
	local r
	r=$(echo "$1" | sed 's/scaling_\(m[a-z]*_freq\)$/scaling_requested_\1/')
	[ "$r" != "$1" ] && [ -f "$r" ] && { cat "$r"; return; }
	cat "$1"
}

# A domain's limits held at LO: PERF.new gets "path old LO" for max, then for
# min (written back in that order: max first, then min); min is lowered first.
hold_domain() {
	local max=$1 min=$2 lo=$3
	echo "$max $(limit_now "$max") $lo" >> "$PERF.new"
	echo "$min $(limit_now "$min") $lo" >> "$PERF.new"
	echo "$lo" > "$min" 2>/dev/null || log "cannot write $min"
	echo "$lo" > "$max" 2>/dev/null || log "cannot write $max"
}

perf_low() {
	local p d lo n=0
	[ -f "$PERF" ] && return
	: > "$PERF.new"
	for p in "$CPUFREQ"/policy*; do
		[ -f "$p/scaling_max_freq" ] || continue
		lo=$(lowest "$p/scaling_available_frequencies")
		[ -n "$lo" ] || lo=$(cat "$p/cpuinfo_min_freq" 2>/dev/null)
		[ -n "$lo" ] || continue
		hold_domain "$p/scaling_max_freq" "$p/scaling_min_freq" "$lo"
		n=$((n + 1))
	done
	for d in "$DEVFREQ"/*; do
		case "${d##*/}" in *gpu*|*GPU*|*mali*) ;; *) continue ;; esac
		lo=$(lowest "$d/available_frequencies")
		[ -n "$lo" ] && [ -f "$d/max_freq" ] || continue
		hold_domain "$d/max_freq" "$d/min_freq" "$lo"
		n=$((n + 1))
	done
	mv -f "$PERF.new" "$PERF"
	log "hotspot off: $n CPU/GPU frequency domains held at their lowest"
}

# The old limits back -- only where they still are what we wrote: a limit
# changed meanwhile (the CPU page) is the user's now, and stays.  And a CPU
# profile saved meanwhile holds our lowest clocks: said in the log.
CPU_PROFILE=/etc/e5-cpu.json
perf_restore() {
	local path old ours kept=0
	[ -f "$PERF" ] || return 0
	while read -r path old ours; do
		[ -n "$old" ] || continue
		if [ -z "$ours" ] || [ "$(limit_now "$path")" = "$ours" ]; then
			echo "$old" > "$path" 2>/dev/null
		else
			kept=$((kept + 1))
		fi
	done < "$PERF"
	[ "$kept" = 0 ] || log "$kept frequency limits changed while held low: left as they were set"
	[ -f "$CPU_PROFILE" ] && [ "$CPU_PROFILE" -nt "$PERF" ] &&
		log "warning: the CPU profile ($CPU_PROFILE) was saved while the clocks were held low; check it on the CPU page"
	rm -f "$PERF"
	log "CPU/GPU frequency limits restored"
}

sim_status_resume() {
	[ -f "$PAUSED" ] || return
	"$SIMSTAT" start >/dev/null 2>&1
	rm -f "$PAUSED"
	log "SIM status polling (t551m-sim-status) resumed"
}

# The radios back on, those it was us who turned off.  A card whose AT owner
# does not answer, or that refuses CFUN=1, keeps its mark: false, and the main
# loop tries again every RADIO_RETRY s (a dropped mark left a card at CFUN 4
# for good, and data never came back).
radio_restore() {
	local c v rc=0
	for c in 0 1; do
		[ -f "$MARK.$c" ] || continue
		v=$(cfun_get "$c")
		case "$v" in
			4)
				if cfun_set "$c" 1; then
					log "cellular radio on (SIM $((c + 1)), AT+CFUN=1)"
					rm -f "$MARK.$c"
				else
					log "AT+CFUN=1 failed (SIM $((c + 1))), again in ${RADIO_RETRY}s"
					rc=1
				fi ;;
			'')
				log "SIM $((c + 1)): no answer to AT+CFUN?, radio on again in ${RADIO_RETRY}s"
				rc=1 ;;
			*)
				rm -f "$MARK.$c" ;;     # (on already, or a CP that restarted)
		esac
	done
	# (after the radio: its first reading is of the card coming back)
	sim_status_resume
	return $rc
}

radio_marked() { [ -f "$MARK.0" ] || [ -f "$MARK.1" ]; }

# ModemManager without a modem ("无模组"): the CP or the WWAN port went away
# and ModemManager forgot it.  While the hotspot is on and that lasts
# MODEM_LOST s, the port is bound again the way e5-sim switches cards --
# ModemManager stopped, sipc_wwan reloaded, ModemManager started -- at most
# once in RECOVER_GAP s, and data brought up after it.
modem_recover() {
	local i c n=0
	i=$(data_iface)
	log "no modem for ${MODEM_LOST}s: binding the modem again (as e5-sim does)"
	ifdown "$i"
	/etc/init.d/modemmanager stop
	/etc/init.d/e5-sipc-wwan restart
	/etc/init.d/modemmanager start
	# the port is back when ModemManager has the modem; its radio as well
	while [ -z "$(modem_state)" ] && [ "$n" -lt 60 ]; do sleep 2; n=$((n + 2)); done
	c=$(data_card)
	[ "$(cfun_get "$c")" = 4 ] && cfun_set "$c" 1 && log "cellular radio on after rebinding (SIM $((c + 1)))"
	rm -f "$MARK.$c"
	ubus call network.interface up "{\"interface\":\"$i\"}"
	if [ -n "$(modem_state)" ]; then
		log "modem back after ${n}s, mobile data ($i) up"
	else
		log "still no modem after rebinding: a reboot may be needed"
	fi
}

# while the hotspot is on: a radio still off, a modem gone
watch_on() {
	local now
	now=$(uptime_s)
	[ "$now" -ge "$watch_next" ] || return
	watch_next=$((now + RADIO_RETRY))
	if radio_marked && radio_restore; then
		data_active "$(data_iface)" ||
			ubus call network.interface up "{\"interface\":\"$(data_iface)\"}"
	fi
	if [ -n "$(modem_state)" ]; then
		lost_since=0
		return
	fi
	[ "$lost_since" -gt 0 ] || lost_since=$now
	[ $((now - lost_since)) -ge "$MODEM_LOST" ] || return
	[ $((now - recovered_at)) -ge "$RECOVER_GAP" ] || return
	recovered_at=$now
	modem_recover
	lost_since=0
}

# disable_modem 0 for mode data, set by us and marked so (managed_dm); given
# back -- deleted, the proto's default 1 -- for mode radio and when we let go
set_keep_radio() {
	local i
	i=$(data_iface)
	if [ "$1" = 1 ]; then
		[ "$(uci -q get "network.$i.disable_modem")" = 0 ] && return
		uci set "network.$i.disable_modem=0"
		uci commit network
		uci set "$CFG.settings.managed_dm=1"
		uci commit "$CFG"
	elif [ "$(uci -q get "$CFG.settings.managed_dm")" = 1 ]; then
		uci -q delete "network.$i.disable_modem"
		uci commit network
		uci -q delete "$CFG.settings.managed_dm"
		uci commit "$CFG"
	fi
}

data_off() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" != 0 ]; then
		uci set "network.$i.auto=0"
		uci commit network
	fi
	if data_active "$i" || data_autostart "$i"; then
		log "hotspot off: mobile data ($i) down"
		ifdown "$i"
		# (the proto's teardown is still running: look at the radio a bit later)
		radio_next=$(($(uptime_s) + 10))
	fi
}

# The radio as the mode wants it while the hotspot is off, looked at every
# RADIO_RETRY s: mode radio keeps it off, mode data puts it back once.
radio_apply() {
	local m s c now
	m=$1
	now=$(uptime_s)
	[ "$now" -ge "$radio_next" ] || return
	radio_next=$((now + RADIO_RETRY))
	data_active "$(data_iface)" && return
	if [ "$m" = data ]; then
		[ "$radio_done" = data ] && return
		radio_restore
		if [ "$(modem_state)" = disabled ]; then
			log "hotspot off, data only: modem enabled for SMS and calls"
			mmcli -m any --timeout=30 --enable >/dev/null 2>&1 || return
		fi
		radio_done=data
		return
	fi
	radio_done=radio
	s=$(modem_state)
	case "$s" in
		# Never touch the radio while ModemManager has no modem or is still
		# probing it: the radio going off under its probe can make it give
		# the device up for good (at boot, with the hotspot off) -- "无模组".
		''|disabling|enabling|initializing) return ;;
		disabled|failed|locked) ;;
		*) mmcli -m any --timeout=30 --disable >/dev/null 2>&1 ;;
	esac
	c=$(data_card)
	case "$(cfun_get "$c")" in
		1)
			: > "$MARK.$c"
			if cfun_set "$c" 4; then
				log "hotspot off: cellular radio off (SIM $((c + 1)), AT+CFUN=4)"
			else
				log "AT+CFUN=4 failed (SIM $((c + 1))), again in ${RADIO_RETRY}s"
				return
			fi ;;
		4)
			[ -f "$MARK.$c" ] || : > "$MARK.$c" ;;
		*)
			return ;;
	esac
	# the radio is off (CFUN 4): nothing for the poller to read
	if pause_wanted; then sim_status_pause; else sim_status_resume; fi
}

# (ubus "up", not ifup: ifup reloads the network and restarts an interface
# that is already up)
data_on() {
	local i
	i=$(data_iface)
	radio_restore
	if [ "$(uci -q get "network.$i.auto")" = 0 ]; then
		uci -q delete "network.$i.auto"
		uci commit network
	fi
	if ! data_active "$i"; then
		log "hotspot on: mobile data ($i) up"
		ubus call network.interface up "{\"interface\":\"$i\"}"
	fi
}

# linking off: everything as it was before the app
give_back() {
	perf_restore
	set_keep_radio 0
	radio_restore
	[ "$(uci -q get "network.$(data_iface).auto")" = 0 ] && data_on
}

# the app is gone: data back to normal, and this service with it
remove_self() {
	give_back
	log "app removed: mobile data restored, service removed"
	"$INIT" disable 2>/dev/null
	rm -f "$INIT"
	# (procd stops this process here)
	ubus call service delete '{"name":"hotspot-data"}'
	exit 0
}

# the version that runs, for the backend: a reinstalled app restarts us
cp "$DIR/service.sh" /var/run/hotspotdata.running 2>/dev/null

state=
off_since=0
radio_done=
radio_next=0
watch_next=0
lost_since=0
recovered_at=-100000
while :; do
	[ -f "$DIR/manifest.json" ] || remove_self
	if ! enabled; then
		if [ "$state" != disabled ]; then
			give_back
			log "linking disabled"
			state=disabled
		elif radio_marked && [ "$(uptime_s)" -ge "$watch_next" ]; then
			# (a radio give_back could not turn on yet)
			watch_next=$(($(uptime_s) + RADIO_RETRY))
			radio_restore && data_on
		fi
	else
		m=$(mode)
		if [ "$m" = data ]; then set_keep_radio 1; else set_keep_radio 0; fi
		if hotspot_on; then
			if [ "$state" != on ]; then
				# (full speed first: the hotspot is about to carry traffic)
				perf_restore
				data_on
				state=on
				lost_since=0
				watch_next=$(($(uptime_s) + RADIO_RETRY))
			fi
			watch_on
		else
			if [ "$state" != off ]; then
				off_since=$(uptime_s)
				radio_done=
				radio_next=0
				state=off
			fi
			# a mode change while off is looked at now
			[ -n "$radio_done" ] && [ "$radio_done" != "$m" ] && radio_next=0
			if [ $(($(uptime_s) - off_since)) -ge "$(off_delay)" ]; then
				data_off
				radio_apply "$m"
				[ -f "$PAUSED" ] && sims_write_off
				if perf_wanted; then perf_low; else perf_restore; fi
			fi
		fi
	fi
	sleep "$INTERVAL"
done
