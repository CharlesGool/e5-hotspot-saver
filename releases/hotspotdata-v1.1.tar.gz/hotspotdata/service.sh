#!/bin/sh
# 热点联动移动数据 -- the background half of the hotspotdata info screen app.
#
#   hotspot turned off -> mobile data down (after off_delay minutes), and with
#                         mode "radio" the modem disabled as well
#   hotspot turned on  -> mobile data up (netifd's modemmanager proto enables
#                         the modem first)
#
# The hotspot's state is its configuration: the first wifi-iface in mode ap and
# its radio, not disabled -- what the screen, LuCI and the dashboard all change
# (/usr/libexec/unisoc-modem/hotspot.uc).  Data is the netifd interface the
# dashboard's own data switch uses (unisoc_modem.main.data_interface, wan).
#
# Modes (e5-plugin-hotspotdata.settings.mode):
#   radio  the cellular radio off: the proto's teardown disables the modem
#          (network.<wan>.disable_modem, default 1) -- the dashboard's
#          "蜂窝射频" off does the same, ifdown and mmcli --disable.  No SMS and
#          no calls until the hotspot is on again.  Never AT+CFUN=0 or SFUN=5:
#          after those the SIM is gone until a reboot (api.uc, at_warning).
#   data   data only: disable_modem 0 keeps the modem registered, so SMS and
#          calls still come in.
#
# While the hotspot is off, network.<wan>.auto is 0 as well, so that a boot, a
# network reload or the modem coming back does not dial again behind our back;
# anything that still brings the interface up (a SIM switch, an APN change, the
# reconnect button, the dashboard's radio button) is taken down again at the
# next check, and in mode radio its teardown disables the modem again.  While
# the hotspot is on, data is only raised on the change: turning data off by
# hand then stays.
#
# /etc/init.d/hotspot-data runs this under procd; the app's backend installs
# that.  When the app is removed or the linking turned off, this gives back
# what it changed (auto, disable_modem); a removed app also removes the service.

DIR=/etc/e5-infoscreen/plugins/hotspotdata
CFG=e5-plugin-hotspotdata
INIT=/etc/init.d/hotspot-data
INTERVAL=3
RADIO_RETRY=30

log() { logger -t hotspotdata -- "$*"; }

data_iface() {
	local i
	i=$(uci -q get unisoc_modem.main.data_interface)
	echo "${i:-wan}"
}

hotspot_on() {
	local ap radio
	ap=$(uci -q show wireless | sed -n "s/^wireless\.\([^.]*\)\.mode='ap'$/\1/p" | head -n 1)
	[ -n "$ap" ] || return 1
	radio=$(uci -q get "wireless.$ap.device")
	[ "$(uci -q get "wireless.$ap.disabled")" != 1 ] &&
		[ "$(uci -q get "wireless.$radio.disabled")" != 1 ]
}

enabled() { [ "$(uci -q get "$CFG.settings.enabled")" != 0 ]; }

mode() {
	case "$(uci -q get "$CFG.settings.mode")" in
		data) echo data ;;
		*) echo radio ;;
	esac
}

off_delay() {
	local d
	d=$(uci -q get "$CFG.settings.off_delay")
	case "$d" in ''|*[!0-9]*) d=0 ;; esac
	echo $((d * 60))
}

uptime_s() { cut -d. -f1 /proc/uptime; }

# 0: up or dialling; 1: down
data_active() {
	local st
	st=$(ifstatus "$1" 2>/dev/null) || return 1
	[ "$(echo "$st" | jsonfilter -e '@.up')" = true ] ||
		[ "$(echo "$st" | jsonfilter -e '@.pending')" = true ]
}

# would netifd dial it on its own (at boot, when the modem appears)?
data_autostart() {
	[ "$(ifstatus "$1" 2>/dev/null | jsonfilter -e '@.autostart')" = true ]
}

# ModemManager's state of the modem: disabled, enabled, registered, ... or
# nothing while there is none
modem_state() {
	mmcli -m any -K 2>/dev/null | sed -n 's/^modem\.generic\.state *: *//p' | head -n 1
}

# disable_modem 0 for mode data, set by us and marked so (managed_dm); given
# back -- deleted, the proto's default 1 -- for mode radio and when we let go
set_keep_radio() {
	local i
	i=$(data_iface)
	if [ "$1" = 1 ]; then
		[ "$(uci -q get "network.$i.disable_modem")" = 0 ] && return
		uci set "network.$i.disable_modem=0"
		uci commit network
		uci set "$CFG.settings.managed_dm=1"
		uci commit "$CFG"
	elif [ "$(uci -q get "$CFG.settings.managed_dm")" = 1 ]; then
		uci -q delete "network.$i.disable_modem"
		uci commit network
		uci -q delete "$CFG.settings.managed_dm"
		uci commit "$CFG"
	fi
}

data_off() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" != 0 ]; then
		uci set "network.$i.auto=0"
		uci commit network
	fi
	if data_active "$i" || data_autostart "$i"; then
		log "hotspot off: mobile data ($i) down"
		ifdown "$i"
		# (the proto's teardown disables the modem in mode radio: look later)
		radio_next=$(($(uptime_s) + 10))
	fi
}

# The radio as the mode wants it while the hotspot is off: once per change
# (radio_done), retried every RADIO_RETRY s while there is no modem yet.
radio_apply() {
	local m s now
	m=$1
	[ "$radio_done" = "$m" ] && return
	now=$(uptime_s)
	[ "$now" -ge "$radio_next" ] || return
	radio_next=$((now + RADIO_RETRY))
	data_active "$(data_iface)" && return
	s=$(modem_state)
	case "$m:$s" in
		*:) return ;;                                   # no modem (yet)
		*:disabling|*:enabling|*:initializing) return ;;
		radio:disabled|*:failed|*:locked) ;;            # (no SIM, PIN: nothing to do)
		radio:*)
			log "hotspot off: cellular radio off (modem $s)"
			mmcli -m any --timeout=30 --disable >/dev/null 2>&1 || return ;;
		data:disabled)
			log "hotspot off, data only: cellular radio on for SMS and calls"
			mmcli -m any --timeout=30 --enable >/dev/null 2>&1 || return ;;
		data:*) ;;
	esac
	radio_done=$m
}

# (ubus "up", not ifup: ifup reloads the network and restarts an interface
# that is already up)
data_on() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" = 0 ]; then
		uci -q delete "network.$i.auto"
		uci commit network
	fi
	if ! data_active "$i"; then
		log "hotspot on: mobile data ($i) up"
		ubus call network.interface up "{\"interface\":\"$i\"}"
	fi
}

# linking off: everything as it was before the app
give_back() {
	set_keep_radio 0
	[ "$(uci -q get "network.$(data_iface).auto")" = 0 ] && data_on
}

# the app is gone: data back to normal, and this service with it
remove_self() {
	give_back
	log "app removed: mobile data restored, service removed"
	"$INIT" disable 2>/dev/null
	rm -f "$INIT"
	# (procd stops this process here)
	ubus call service delete '{"name":"hotspot-data"}'
	exit 0
}

# the version that runs, for the backend: a reinstalled app restarts us
cp "$DIR/service.sh" /var/run/hotspotdata.running 2>/dev/null

state=
off_since=0
radio_done=
radio_next=0
while :; do
	[ -f "$DIR/manifest.json" ] || remove_self
	if ! enabled; then
		if [ "$state" != disabled ]; then
			give_back
			log "linking disabled"
			state=disabled
		fi
	else
		m=$(mode)
		if [ "$m" = data ]; then set_keep_radio 1; else set_keep_radio 0; fi
		if hotspot_on; then
			if [ "$state" != on ]; then
				data_on
				state=on
			fi
		else
			if [ "$state" != off ]; then
				off_since=$(uptime_s)
				radio_done=
				state=off
			fi
			if [ $(($(uptime_s) - off_since)) -ge "$(off_delay)" ]; then
				data_off
				radio_apply "$m"
			fi
		fi
	fi
	sleep "$INTERVAL"
done
