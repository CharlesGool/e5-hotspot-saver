#!/bin/sh
# 热点联动移动数据 -- the background half of the hotspotdata info screen app.
#
#   hotspot turned off -> mobile data down (after off_delay minutes), and with
#                         mode "radio" the data card's radio off as well
#   hotspot turned on  -> the radio back on, mobile data up
#
# The hotspot's state is its configuration: the first wifi-iface in mode ap and
# its radio, not disabled -- what the screen, LuCI and the dashboard all change
# (/usr/libexec/unisoc-modem/hotspot.uc).  Data is the netifd interface the
# dashboard's own data switch uses (unisoc_modem.main.data_interface, wan).
#
# Modes (e5-plugin-hotspotdata.settings.mode):
#   radio  the cellular radio off.  ModemManager's disable (the proto's
#          teardown, network.<wan>.disable_modem default 1) is not enough on
#          this modem: the card stays at CFUN 1, camped (t551m-sim-status still
#          reads its operator).  So the data card also gets AT+CFUN=4 -- radio
#          off, SIM kept, what the dashboard does to a standby card -- through
#          the AT adapter with the card selected (MU300_SIM_SLOT ->
#          AT+SPACTCARD), and AT+CFUN=1 before data comes back.  Never
#          AT+CFUN=0 or SFUN=3/5: after those the SIM is gone until a reboot
#          (api.uc, at_warning).  No SMS and no calls while it is off.
#   data   data only: disable_modem 0 keeps the modem registered, so SMS and
#          calls still come in.
#
# While the hotspot is off, network.<wan>.auto is 0 as well, so that a boot, a
# network reload or the modem coming back does not dial again behind our back;
# anything that still brings the interface up (a SIM switch, an APN change, the
# reconnect button, the dashboard's radio button) is taken down again at the
# next check, and in mode radio the radio is checked (AT+CFUN?) every
# RADIO_RETRY s and turned off again.  While the hotspot is on, data is only
# raised on the change: turning data off by hand then stays.
#
# /etc/init.d/hotspot-data runs this under procd; the app's backend installs
# that.  When the app is removed or the linking turned off, this gives back
# what it changed (auto, disable_modem, the radio); a removed app also removes
# the service.

DIR=/etc/e5-infoscreen/plugins/hotspotdata
CFG=e5-plugin-hotspotdata
INIT=/etc/init.d/hotspot-data
AT=/usr/libexec/unisoc-modem/at
# MARK.<card>: a card whose radio we turned off (kept until a reboot, which
# powers it anyway); one each, so a data SIM switched while off is given back too
MARK=/var/run/hotspotdata.radio-off
# t551m-sim-status reads both cards over AT every 5 s, radio off or not; with
# pause_sim_status it is stopped while the radio is off (PAUSED: stopped by us,
# so started again by us).  Its readers (the status bar, the dashboard's
# per-card rows) take a reading older than 15 s as unknown.  Our own AT goes
# through e5-at, not through it.
SIMSTAT=/etc/init.d/t551m-sim-status
PAUSED=/var/run/hotspotdata.simstatus-paused
INTERVAL=3
RADIO_RETRY=30

log() { logger -t hotspotdata -- "$*"; }

data_iface() {
	local i
	i=$(uci -q get unisoc_modem.main.data_interface)
	echo "${i:-wan}"
}

# the data SIM (sipc_wwan card=, e5-sim)
data_card() {
	local c
	c=$(cat /sys/module/sipc_wwan/parameters/card 2>/dev/null)
	case "$c" in 0|1) echo "$c" ;; *) echo 0 ;; esac
}

hotspot_on() {
	local ap radio
	ap=$(uci -q show wireless | sed -n "s/^wireless\.\([^.]*\)\.mode='ap'$/\1/p" | head -n 1)
	[ -n "$ap" ] || return 1
	radio=$(uci -q get "wireless.$ap.device")
	[ "$(uci -q get "wireless.$ap.disabled")" != 1 ] &&
		[ "$(uci -q get "wireless.$radio.disabled")" != 1 ]
}

enabled() { [ "$(uci -q get "$CFG.settings.enabled")" != 0 ]; }

mode() {
	case "$(uci -q get "$CFG.settings.mode")" in
		data) echo data ;;
		*) echo radio ;;
	esac
}

off_delay() {
	local d
	d=$(uci -q get "$CFG.settings.off_delay")
	case "$d" in ''|*[!0-9]*) d=0 ;; esac
	echo $((d * 60))
}

uptime_s() { cut -d. -f1 /proc/uptime; }

# 0: up or dialling; 1: down
data_active() {
	local st
	st=$(ifstatus "$1" 2>/dev/null) || return 1
	[ "$(echo "$st" | jsonfilter -e '@.up')" = true ] ||
		[ "$(echo "$st" | jsonfilter -e '@.pending')" = true ]
}

# would netifd dial it on its own (at boot, when the modem appears)?
data_autostart() {
	[ "$(ifstatus "$1" 2>/dev/null | jsonfilter -e '@.autostart')" = true ]
}

# ModemManager's state of the modem: disabled, enabled, registered, ... or
# nothing while there is none
modem_state() {
	mmcli -m any -K 2>/dev/null | sed -n 's/^modem\.generic\.state *: *//p' | head -n 1
}

# the card's radio: 1 on, 4 off, 0 minimum; nothing when the AT owner does not answer
cfun_get() {
	MU300_SIM_SLOT=$1 "$AT" -t 10 'AT+CFUN?' 2>/dev/null |
		sed -n 's/.*+CFUN: *\([0-9]*\).*/\1/p' | head -n 1
}

cfun_set() {
	MU300_SIM_SLOT=$1 "$AT" -t 15 "AT+CFUN=$2" 2>/dev/null | grep -q '^OK'
}

pause_wanted() { [ "$(uci -q get "$CFG.settings.pause_sim_status")" != 0 ]; }

# (also when something started it again while paused)
sim_status_pause() {
	[ -x "$SIMSTAT" ] || return
	ubus call service list '{"name":"t551m-sim-status"}' 2>/dev/null |
		grep -q '"running": *true' || return
	: > "$PAUSED"
	"$SIMSTAT" stop >/dev/null 2>&1
	log "radio off: SIM status polling (t551m-sim-status) paused"
}

sim_status_resume() {
	[ -f "$PAUSED" ] || return
	"$SIMSTAT" start >/dev/null 2>&1
	rm -f "$PAUSED"
	log "SIM status polling (t551m-sim-status) resumed"
}

# the radios back on, those it was us who turned off
radio_restore() {
	local c
	for c in 0 1; do
		[ -f "$MARK.$c" ] || continue
		if [ "$(cfun_get "$c")" = 4 ]; then
			if cfun_set "$c" 1; then
				log "cellular radio on (SIM $((c + 1)), AT+CFUN=1)"
			else
				log "AT+CFUN=1 failed (SIM $((c + 1))); ModemManager will try when data comes up"
			fi
		fi
		rm -f "$MARK.$c"
	done
	# (after the radio: its first reading is of the card coming back)
	sim_status_resume
}

# disable_modem 0 for mode data, set by us and marked so (managed_dm); given
# back -- deleted, the proto's default 1 -- for mode radio and when we let go
set_keep_radio() {
	local i
	i=$(data_iface)
	if [ "$1" = 1 ]; then
		[ "$(uci -q get "network.$i.disable_modem")" = 0 ] && return
		uci set "network.$i.disable_modem=0"
		uci commit network
		uci set "$CFG.settings.managed_dm=1"
		uci commit "$CFG"
	elif [ "$(uci -q get "$CFG.settings.managed_dm")" = 1 ]; then
		uci -q delete "network.$i.disable_modem"
		uci commit network
		uci -q delete "$CFG.settings.managed_dm"
		uci commit "$CFG"
	fi
}

data_off() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" != 0 ]; then
		uci set "network.$i.auto=0"
		uci commit network
	fi
	if data_active "$i" || data_autostart "$i"; then
		log "hotspot off: mobile data ($i) down"
		ifdown "$i"
		# (the proto's teardown is still running: look at the radio a bit later)
		radio_next=$(($(uptime_s) + 10))
	fi
}

# The radio as the mode wants it while the hotspot is off, looked at every
# RADIO_RETRY s: mode radio keeps it off, mode data puts it back once.
radio_apply() {
	local m s c now
	m=$1
	now=$(uptime_s)
	[ "$now" -ge "$radio_next" ] || return
	radio_next=$((now + RADIO_RETRY))
	data_active "$(data_iface)" && return
	if [ "$m" = data ]; then
		[ "$radio_done" = data ] && return
		radio_restore
		if [ "$(modem_state)" = disabled ]; then
			log "hotspot off, data only: modem enabled for SMS and calls"
			mmcli -m any --timeout=30 --enable >/dev/null 2>&1 || return
		fi
		radio_done=data
		return
	fi
	radio_done=radio
	s=$(modem_state)
	case "$s" in
		disabling|enabling|initializing) return ;;
		''|disabled|failed|locked) ;;
		*) mmcli -m any --timeout=30 --disable >/dev/null 2>&1 ;;
	esac
	c=$(data_card)
	case "$(cfun_get "$c")" in
		1)
			: > "$MARK.$c"
			if cfun_set "$c" 4; then
				log "hotspot off: cellular radio off (SIM $((c + 1)), AT+CFUN=4)"
			else
				log "AT+CFUN=4 failed (SIM $((c + 1))), again in ${RADIO_RETRY}s"
				return
			fi ;;
		4)
			[ -f "$MARK.$c" ] || : > "$MARK.$c" ;;
		*)
			return ;;
	esac
	# the radio is off (CFUN 4): nothing for the poller to read
	if pause_wanted; then sim_status_pause; else sim_status_resume; fi
}

# (ubus "up", not ifup: ifup reloads the network and restarts an interface
# that is already up)
data_on() {
	local i
	i=$(data_iface)
	radio_restore
	if [ "$(uci -q get "network.$i.auto")" = 0 ]; then
		uci -q delete "network.$i.auto"
		uci commit network
	fi
	if ! data_active "$i"; then
		log "hotspot on: mobile data ($i) up"
		ubus call network.interface up "{\"interface\":\"$i\"}"
	fi
}

# linking off: everything as it was before the app
give_back() {
	set_keep_radio 0
	radio_restore
	[ "$(uci -q get "network.$(data_iface).auto")" = 0 ] && data_on
}

# the app is gone: data back to normal, and this service with it
remove_self() {
	give_back
	log "app removed: mobile data restored, service removed"
	"$INIT" disable 2>/dev/null
	rm -f "$INIT"
	# (procd stops this process here)
	ubus call service delete '{"name":"hotspot-data"}'
	exit 0
}

# the version that runs, for the backend: a reinstalled app restarts us
cp "$DIR/service.sh" /var/run/hotspotdata.running 2>/dev/null

state=
off_since=0
radio_done=
radio_next=0
while :; do
	[ -f "$DIR/manifest.json" ] || remove_self
	if ! enabled; then
		if [ "$state" != disabled ]; then
			give_back
			log "linking disabled"
			state=disabled
		fi
	else
		m=$(mode)
		if [ "$m" = data ]; then set_keep_radio 1; else set_keep_radio 0; fi
		if hotspot_on; then
			if [ "$state" != on ]; then
				data_on
				state=on
			fi
		else
			if [ "$state" != off ]; then
				off_since=$(uptime_s)
				radio_done=
				radio_next=0
				state=off
			fi
			# a mode change while off is looked at now
			[ -n "$radio_done" ] && [ "$radio_done" != "$m" ] && radio_next=0
			if [ $(($(uptime_s) - off_since)) -ge "$(off_delay)" ]; then
				data_off
				radio_apply "$m"
			fi
		fi
	fi
	sleep "$INTERVAL"
done
