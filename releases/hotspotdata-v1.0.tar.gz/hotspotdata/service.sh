#!/bin/sh
# 热点联动移动数据 -- the background half of the hotspotdata info screen app.
#
#   hotspot turned off -> mobile data down (after off_delay minutes)
#   hotspot turned on  -> mobile data up
#
# The hotspot's state is its configuration: the first wifi-iface in mode ap and
# its radio, not disabled -- what the screen, LuCI and the dashboard all change
# (/usr/libexec/unisoc-modem/hotspot.uc).  Data is the netifd interface the
# dashboard's own data switch uses (unisoc_modem.main.data_interface, wan).
#
# While the hotspot is off, network.<wan>.auto is 0 as well, so that a boot, a
# network reload or the modem coming back does not dial again behind our back;
# anything that still brings the interface up (a SIM switch, an APN change, the
# reconnect button) is taken down again at the next check.  While the hotspot
# is on, data is only raised on the change: turning data off by hand then stays.
#
# /etc/init.d/hotspot-data runs this under procd; the app's backend installs
# that.  When the app is removed, this gives the data connection back and
# removes the service.

DIR=/etc/e5-infoscreen/plugins/hotspotdata
CFG=e5-plugin-hotspotdata
INIT=/etc/init.d/hotspot-data
INTERVAL=3

log() { logger -t hotspotdata -- "$*"; }

data_iface() {
	local i
	i=$(uci -q get unisoc_modem.main.data_interface)
	echo "${i:-wan}"
}

hotspot_on() {
	local ap radio
	ap=$(uci -q show wireless | sed -n "s/^wireless\.\([^.]*\)\.mode='ap'$/\1/p" | head -n 1)
	[ -n "$ap" ] || return 1
	radio=$(uci -q get "wireless.$ap.device")
	[ "$(uci -q get "wireless.$ap.disabled")" != 1 ] &&
		[ "$(uci -q get "wireless.$radio.disabled")" != 1 ]
}

enabled() { [ "$(uci -q get "$CFG.settings.enabled")" != 0 ]; }

off_delay() {
	local d
	d=$(uci -q get "$CFG.settings.off_delay")
	case "$d" in ''|*[!0-9]*) d=0 ;; esac
	echo $((d * 60))
}

uptime_s() { cut -d. -f1 /proc/uptime; }

# 0: up or dialling; 1: down
data_active() {
	local st
	st=$(ifstatus "$1" 2>/dev/null) || return 1
	[ "$(echo "$st" | jsonfilter -e '@.up')" = true ] ||
		[ "$(echo "$st" | jsonfilter -e '@.pending')" = true ]
}

# would netifd dial it on its own (at boot, when the modem appears)?
data_autostart() {
	[ "$(ifstatus "$1" 2>/dev/null | jsonfilter -e '@.autostart')" = true ]
}

data_off() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" != 0 ]; then
		uci set "network.$i.auto=0"
		uci commit network
	fi
	if data_active "$i" || data_autostart "$i"; then
		log "hotspot off: mobile data ($i) down"
		ifdown "$i"
	fi
}

# (ubus "up", not ifup: ifup reloads the network and restarts an interface
# that is already up)
data_on() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" = 0 ]; then
		uci -q delete "network.$i.auto"
		uci commit network
	fi
	if ! data_active "$i"; then
		log "hotspot on: mobile data ($i) up"
		ubus call network.interface up "{\"interface\":\"$i\"}"
	fi
}

# the app is gone: data back to normal, and this service with it
remove_self() {
	local i
	i=$(data_iface)
	if [ "$(uci -q get "network.$i.auto")" = 0 ]; then
		uci -q delete "network.$i.auto"
		uci commit network
		data_active "$i" || ubus call network.interface up "{\"interface\":\"$i\"}"
	fi
	log "app removed: mobile data restored, service removed"
	"$INIT" disable 2>/dev/null
	rm -f "$INIT"
	# (procd stops this process here)
	ubus call service delete '{"name":"hotspot-data"}'
	exit 0
}

state=
off_since=0
while :; do
	[ -f "$DIR/manifest.json" ] || remove_self
	if ! enabled; then
		if [ "$state" != disabled ]; then
			# give back what an earlier "off" took
			[ "$(uci -q get "network.$(data_iface).auto")" = 0 ] && data_on
			log "linking disabled"
			state=disabled
		fi
	elif hotspot_on; then
		if [ "$state" != on ]; then
			data_on
			state=on
		fi
	else
		if [ "$state" != off ]; then
			off_since=$(uptime_s)
			state=off
		fi
		[ $(($(uptime_s) - off_since)) -ge "$(off_delay)" ] && data_off
	fi
	sleep "$INTERVAL"
done
